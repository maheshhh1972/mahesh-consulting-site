MAHESH CONSULTING WEBSITE — PUBLISHING GUIDE

FILES
- index.html: complete responsive one-page website; no build tools required.
- README.txt: publishing instructions.

BEFORE PUBLISHING
1. Review all statements and ensure they accurately describe the business.
2. Add genuine company details (registered business name, location, phone, service specifics) if desired.
3. Do not add client names, logos, case studies, revenue claims, certifications or testimonials unless accurate and authorised.
4. Contact email currently uses maheshtomar@maheshconsulting.com.

FREE HOSTING WITH GITHUB PAGES
1. Create/sign into a GitHub account at https://github.com/
2. Create a NEW public repository named: mahesh-consulting-site
3. Upload index.html to the repository root (Add file > Upload files > Commit changes).
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch; branch main; folder /(root); Save.
6. Wait for the site URL, typically https://YOUR-GITHUB-USERNAME.github.io/mahesh-consulting-site/
7. Test that URL before connecting your domain.

CONNECT GODADDY DOMAIN
The domain is maheshconsulting.com. The email address is not the domain; do not enter the email into a website/domain field.

1. First add the custom domain in GitHub: repository > Settings > Pages > Custom domain.
   Enter www.maheshconsulting.com and Save.
2. In GoDaddy, open My Products > Domains > maheshconsulting.com > DNS / Manage DNS.
3. Add/update a record:
   Type: CNAME | Name/Host: www | Value/Points to: YOUR-GITHUB-USERNAME.github.io
   Replace YOUR-GITHUB-USERNAME with your actual GitHub username. Do not include the repository name.
4. For root domain maheshconsulting.com, add four A records with Host/Name @:
   185.199.108.153
   185.199.109.153
   185.199.110.153
   185.199.111.153
   Remove conflicting old website A records for @ only if you know they belong to an old website.
5. DO NOT delete or change MX, SPF, DKIM, DMARC or other email-related DNS records. These can break your existing business email.
6. In GitHub Settings > Pages, enable Enforce HTTPS once available.
7. DNS propagation can take up to 24 hours; HTTPS certificate issuance can take additional time.

SAFETY / TROUBLESHOOTING
- Add the custom domain in GitHub before changing DNS, as GitHub recommends.
- Do not change nameservers unless you understand the consequences.
- Do not delete MX or TXT records related to email.
- If DNS is managed somewhere other than GoDaddy, make changes at the active DNS provider.
- Official instructions:
https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site

CLAUDE STARTUPS APPLICATION
Submit the live URL only after publishing and testing. Ensure all information is accurate. The site describes the consultancy and intended AI-assisted workflows; it does not claim a finished AI product exists.
